package com.cg.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.project.bean.Account;
import com.cg.project.exception.AccountException;
import com.cg.project.service.AccountService;
import com.cg.project.service.TransactionService;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class AccountController {
	
	@Autowired
	AccountService accountService;
	
	@Autowired
	TransactionService transactionService;
	
	
	@RequestMapping(value="/account/{accnumber}", method = RequestMethod.GET, produces = "application/json")
	public Account findAccountDetailsByAccountNumber(@PathVariable int accnumber) throws AccountException {
		return accountService.getAccountDetailsByAccountNumber(accnumber);
	}

	@PostMapping("/account")
	public List<Account> create(@RequestBody Account account) throws AccountException {
		return accountService.addAccount(account);
	}
	

	 @PutMapping("/account/{accnumber}/{amount}")
	 public Account moneyDeposit(@PathVariable("accnumber") int accnumber, @PathVariable("amount") int amount) throws AccountException {
		 transactionService.addTransaction("Amount "+amount+" added to your account",accnumber);
		 return accountService.depositMoney(accnumber, amount); 
	}
	 
	 
	 @PutMapping("/accountw/{accnumber}/{amount}")
	 public Account moneyWithdrawal(@PathVariable("accnumber") int accnumber, @PathVariable("amount") int amount) throws AccountException {
		 transactionService.addTransaction("Amount "+amount+" Withdraw to your account",accnumber);
		 return accountService.withdrawMoney(accnumber, amount); 
	}
	 
	 
	 @PutMapping("/accountt/{accountNo1}/{accountNo2}/{amount}")
	 public boolean moneyTransfer(@PathVariable int accountNo1, @PathVariable int accountNo2, @PathVariable int amount) throws AccountException{
		 transactionService.addTransaction("Amount "+amount+" deducted from account and added to account with id " + accountNo2 + ".", accountNo1);
		 return accountService.fundTransferUpdate(accountNo1, accountNo2, amount);
	 }
	 
	 @PutMapping("/account")
	 public List<Account> updateDetial(@RequestBody Account account) throws AccountException{
		 return accountService.updateDetials(account);
	 }
	 
	 @RequestMapping(value="/account/{username}/{password}", method = RequestMethod.GET, produces = "application/json")
		public Account findAccountDetailsByUsername(@PathVariable String username, @PathVariable String password) throws AccountException {
			return accountService.getAccountDetailsByUsername(username, password);
		}
	 
	 @RequestMapping("/getTransactions/all/{id}")
	    public List<String> getTransactions(@PathVariable int id) {
	        return transactionService.getTransaction(id);
	    }
}
