package com.cg.project.exception;

public class AccountException extends Exception{
	
	public AccountException() {
		super();
	}
	
	
	public AccountException(String message) {
		super(message);
	}

}
