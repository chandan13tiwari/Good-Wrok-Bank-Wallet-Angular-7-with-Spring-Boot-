export class Accounts {

    accnumber: string;
    name: string;
    phone: string;
    dob: string;
    address: string;
    aadharcard: string;
    balance: string;
    username: string;
    password: string;
}
