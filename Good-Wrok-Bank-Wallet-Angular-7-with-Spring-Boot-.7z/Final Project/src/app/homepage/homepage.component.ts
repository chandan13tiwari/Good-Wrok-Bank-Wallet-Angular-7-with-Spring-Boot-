import { Component, OnInit } from '@angular/core';
import { AccountService } from '../account.service';
import { Router } from '@angular/router';
import { Accounts } from '../accounts';
import { IfStmt } from '@angular/compiler';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {

  account: Accounts = new Accounts();

  acco: Accounts = new Accounts();

  constructor(private _AccountService: AccountService, public router: Router) { }

  ngOnInit() {

  }

  userAccountNumber: string;
  userName: string;
  userPhone: string;
  userDateOfBirth: string;
  userAddress: string;
  userAadharCard: string;
  userBalance: string;


  handleSuccessfulResponse(response, username, password) {
    this.account = response;
    console.log(this.account);

    this.userAccountNumber = this.account.accnumber;
    this.userName = this.account.name;
    this.userAddress = this.account.address;
    this.userBalance = this.account.balance;
    this.userDateOfBirth = this.account.dob;
    this.userPhone = this.account.phone;
    this.userAadharCard = this.account.aadharcard;
    console.log(this.userAccountNumber);

    if ((this.account.username === username) && (this.account.password === password)) {
      this._AccountService.passAccountNumber(this.userAccountNumber);
      alert("Login Succesfully");


      this.router.navigate(['/menu']);
    }
    else
      alert("Login Failed.");
  }


  onSubmit(username, password) {
    this._AccountService.getAccountDetailsByUsers(username, password)
      .subscribe(response => this.handleSuccessfulResponse(response, username, password),
        (error) => alert("Login Failed.. Enter correct Credentials"));




  }

}
