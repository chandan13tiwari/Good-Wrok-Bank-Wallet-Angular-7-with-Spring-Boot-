import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AccountDetailsComponent } from './account-details/account-details.component';
import { AccountService } from './account.service';
import { AddAccountComponent } from './add-account/add-account.component';
import { FormsModule } from '@angular/forms';
import { HomepageComponent } from './homepage/homepage.component';
import { NewAccountComponent } from './new-account/new-account.component';
import { MenuComponent } from './menu/menu.component';
import { DepositAmountComponent } from './deposit-amount/deposit-amount.component';
import { WithdrawlAmountComponent } from './withdrawl-amount/withdrawl-amount.component';
import { FundTransferComponent } from './fund-transfer/fund-transfer.component';
import { UpdateDetailsComponent } from './update-details/update-details.component';
import { TransactionComponent } from './transaction/transaction.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { AuthGuardService } from './auth-guard.service';

@NgModule({
  declarations: [
    AppComponent,
    AccountDetailsComponent,
    AddAccountComponent,
    HomepageComponent,
    NewAccountComponent,
    MenuComponent,
    DepositAmountComponent,
    WithdrawlAmountComponent,
    FundTransferComponent,
    UpdateDetailsComponent,
    TransactionComponent,
    PageNotFoundComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [AccountService, AuthGuardService],
  bootstrap: [AppComponent]
})
export class AppModule { }
