import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Accounts } from './accounts';
import { Observable, ObservableLike } from 'rxjs';

@Injectable({
  providedIn: 'root'
})


export class AccountService {

  constructor(private httpClient: HttpClient) { }
  private _url: string = 'http://localhost:8089/api/account'; //the base url
  private _turl: string = 'http://localhost:8089/api/getTransactions/all/';
  private accountNumber: string;
  private loginStatus: boolean;

  getAccountDetails(acc: string): Observable<any>  //here acc is the hardcoded account number
  {
    console.log("test call");
    return this.httpClient.get<Accounts[]>(this._url + '/' + acc); //url for getting the details of customer with the account number and the url should be same as the url in boot
  }

  public createAccount(account: any): Observable<any> { //here account is the requestbody means all the details
    return this.httpClient.post<Accounts[]>(this._url, account); //for registring the new account with the same url
  }

  public depositAmount(accnumber: string, amount: any): Observable<any> {
    return this.httpClient.put<Accounts[]>(this._url + '/' + accnumber + '/' + amount, ""); //same url for deposit amount in boot and the empty request body
  }

  public withdrawAmount(accnumber: string, amount: any): Observable<any> {
    return this.httpClient.put<Accounts[]>(this._url + 'w/' + accnumber + '/' + amount, ""); //same as deposit amount
  }

  public transferAmount(accnumber: string, accnumber2: string, amount: any): Observable<any> {
    return this.httpClient.put<Accounts[]>(this._url + 't/' + accnumber + '/' + accnumber2 + '/' + amount, ""); //same as above
  }

  public updateDetails(account: any): Observable<any> {
    return this.httpClient.post<Accounts[]>(this._url, account);
  }

  public getAccountDetailsByUsers(username: string, password: string): Observable<any> {
    return this.httpClient.get<Accounts[]>(this._url + '/' + username + '/' + password);
  }

  public passAccountNumber(accountNumber) {
    this.accountNumber = accountNumber;
  }

  public returnAccountNumber() {
    return this.accountNumber;
  }

  private username: string;
  private password: string;

  public passUsernameAndPassword(username, password) {
    this.username = username;
    this.password = password;
  }

  public getPassword() {
    return this.password;
  }
  public getUsername() {
    return this.username;
  }


  public getTransactionsByAccountNo(): Observable<string[]> {
    console.log("sds" + this.returnAccountNumber());
    console.log(this._turl + this.returnAccountNumber());
    return this.httpClient.get<string[]>(this._turl + this.returnAccountNumber());
  }

  // public setLoginStatus(loginStatus: boolean){
  //   this.loginStatus = loginStatus;
  // }

  // public getLoginStatus(){
  //   return this.loginStatus;
  // }
}
