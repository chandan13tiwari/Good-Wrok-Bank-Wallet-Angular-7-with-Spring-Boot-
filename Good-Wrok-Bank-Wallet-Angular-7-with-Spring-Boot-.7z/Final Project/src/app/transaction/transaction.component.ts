import { Component, OnInit } from '@angular/core';
import { AccountService } from '../account.service';

@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css']
})
export class TransactionComponent implements OnInit {

  constructor(private _AccountService: AccountService) { }



  transactions: string[];


  ngOnInit() {
    this._AccountService.getTransactionsByAccountNo().subscribe(data => {
      this.transactions = data;

      console.log(this.transactions);
    })
  }

}
