import { Component, OnInit } from '@angular/core';
import { Accounts } from '../accounts';
import { AccountService } from '../account.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-update-details',
  templateUrl: './update-details.component.html',
  styleUrls: ['./update-details.component.css']
})
export class UpdateDetailsComponent implements OnInit {

  account: Accounts = new Accounts();
  submitted = false;

  acco: Accounts = new Accounts();


  constructor(private _AccountService: AccountService, public router: Router) { }

  ngOnInit() {
    this._AccountService.getAccountDetails(this._AccountService.returnAccountNumber())
      .subscribe(response => this.handleSuccessfulResponse(response))
  }

  userAccountNumber: string;
  userName: string;
  userPhone: string;
  userDateOfBirth: string;
  userAddress: string;
  userAadharCard: string;
  userBalance: string;
  userUsername: string;
  userPassword: string;

  handleSuccessfulResponse(response) {
    this.account = response;
    console.log(this.account);

    this.userAccountNumber = this.account.accnumber;
    this.userName = this.account.name;
    this.userAddress = this.account.address;
    this.userBalance = this.account.balance;
    this.userDateOfBirth = this.account.dob;
    this.userPhone = this.account.phone;
    this.userAadharCard = this.account.aadharcard;
    this.userUsername = this.account.username;
    this.userPassword = this.account.password;
    console.log(this.userAccountNumber);
  }

  newAccount(): void {

    this.account = new Accounts();

  }
  save(): void {

    console.log("hii");
    this._AccountService.updateDetails(this.account)
      .subscribe(data => {
        alert("Employee updated successfully.");

        this.router.navigate(['/menu']);
      },
        error => console.log(error));
  };


  onSubmit() {
    console.log("submit");
    this.save();
  }

}
