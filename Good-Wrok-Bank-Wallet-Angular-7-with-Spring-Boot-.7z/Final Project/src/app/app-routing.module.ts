import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AccountDetailsComponent } from './account-details/account-details.component';
import { MenuComponent } from './menu/menu.component';
import { HomepageComponent } from './homepage/homepage.component';
import { AddAccountComponent } from './add-account/add-account.component';
import { NewAccountComponent } from './new-account/new-account.component';
import { DepositAmountComponent } from './deposit-amount/deposit-amount.component';
import { WithdrawlAmountComponent } from './withdrawl-amount/withdrawl-amount.component';
import { FundTransferComponent } from './fund-transfer/fund-transfer.component';
import { TransactionComponent } from './transaction/transaction.component';
import { UpdateDetailsComponent } from './update-details/update-details.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { AuthGuardService } from './auth-guard.service';


const routes: Routes = [
  {
    path: 'homepage',
    component: HomepageComponent,


  },
  {
    path: 'menu',
    component: MenuComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: 'createAccount',
    component: AddAccountComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: 'newAccount',
    component: NewAccountComponent
  },
  {
    path: 'balance',
    component: AccountDetailsComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: 'deposit',
    component: DepositAmountComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: 'withdrawl',
    component: WithdrawlAmountComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: 'fundtransfer',
    component: FundTransferComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: 'transaction',
    component: TransactionComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: 'update',
    component: UpdateDetailsComponent,
    canActivate: [AuthGuardService]
  },

  {
    path: '',
    redirectTo: 'homepage',
    pathMatch: 'full'
  },
  {
    path: 'notFound',
    component: PageNotFoundComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
