import { Component, OnInit } from '@angular/core';
import { AccountService } from '../account.service';
import { Accounts } from '../accounts';

@Component({
  selector: 'app-fund-transfer',
  templateUrl: './fund-transfer.component.html',
  styleUrls: ['./fund-transfer.component.css']
})
export class FundTransferComponent implements OnInit {

  account: Accounts = new Accounts();
  acco: Accounts = new Accounts();

  constructor(private _accountservice: AccountService) { }

  ngOnInit() {

    this._accountservice.getAccountDetails(this._accountservice.returnAccountNumber())
      .subscribe(response => this.handleSuccessfulResponse(response))


  }

  userAccountNumber: string;
  userName: string;
  userPhone: string;
  userDateOfBirth: string;
  userAddress: string;
  userAadharCard: string;
  userBalance: string;

  handleSuccessfulResponse(response) {
    this.account = response;
    console.log(this.account);

    this.userAccountNumber = this.account.accnumber;
    this.userName = this.account.name;
    this.userAddress = this.account.address;
    this.userBalance = this.account.balance;
    this.userDateOfBirth = this.account.dob;
    this.userPhone = this.account.phone;
    this.userAadharCard = this.account.aadharcard;
    console.log(this.userAccountNumber);
  }


  onSubmit(recipaccount, amount) {
    console.log("hii" + amount);
    this._accountservice.transferAmount(this.userAccountNumber, recipaccount, amount)
      .subscribe(data => {
        alert("Money transfered successfully.");

      },
        error => console.log(error));
    this.account = new Accounts();

  }

}
