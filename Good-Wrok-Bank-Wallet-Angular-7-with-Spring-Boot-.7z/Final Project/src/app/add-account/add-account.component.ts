import { Component, OnInit } from '@angular/core';
import { AccountService } from '../account.service';
import { Accounts } from '../accounts';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-account',
  templateUrl: './add-account.component.html',
  styleUrls: ['./add-account.component.css']
})
export class AddAccountComponent implements OnInit {

  account: Accounts = new Accounts();
  submitted = false;

  namePattern: string = "[A-Z]";
  phonePattern: string = "(\\+91(-)?|91(-)?|0(-)?)[9876][0-9]{9}";
  aadharPattern: string = "[0-9]{13}";

  checkValid: boolean = false;

  constructor(private _AccountService: AccountService, public router: Router) { }

  username: string = this._AccountService.getUsername();
  password: string = this._AccountService.getPassword();



  ngOnInit() {
    console.log(this.username);
    console.log(this.password);
    this.account.username = this.username;
    this.account.password = this.password;
  }

  newAccount(): void {

    this.account = new Accounts();


  }
  save(): void {

    console.log("hii");

    if(this.account.name.match(this.namePattern) && this.account.phone.match(this.phonePattern) && this.account.aadharcard.match(this.aadharPattern)){

    this._AccountService.createAccount(this.account)
      .subscribe(data => {
        alert("Employee created successfully.");

        this.router.navigate(['/homepage']);
      },
        error => console.log(error));
    }
    else{
      alert("Name/Phone/aadharCard details are not correct");
    }
  };


  onSubmit() {
    console.log("submit");
    this.save();
  }


}
