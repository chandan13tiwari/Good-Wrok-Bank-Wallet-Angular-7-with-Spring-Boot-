import { Component, OnInit } from '@angular/core';
import { AccountService } from '../account.service';
import { Accounts } from '../accounts';
import { Router } from '@angular/router';

@Component({
  selector: 'app-account-details',
  templateUrl: './account-details.component.html',
  styleUrls: ['./account-details.component.css']
})
export class AccountDetailsComponent implements OnInit {

  constructor(private _accountservice: AccountService, public router: Router) { }

  accounts: Accounts;
  public accnumber: string;

  userAccountNumber: string;
  userName: string;
  userPhone: string;
  userDateOfBirth: string;
  userAddress: string;
  userAadharCard: string;
  userBalance: string;


  ngOnInit() {


    this._accountservice.getAccountDetails(this._accountservice.returnAccountNumber())
      .subscribe(response => this.handleSuccessfulResponse(response))
  }

  handleSuccessfulResponse(response) {
    this.accounts = response;
    console.log(this.accounts);
    
    this.userAccountNumber = this.accounts.accnumber;
    this.userName = this.accounts.name;
    this.userAddress = this.accounts.address;
    this.userBalance = this.accounts.balance;
    this.userDateOfBirth = this.accounts.dob;
    this.userPhone = this.accounts.phone;
    this.userAadharCard = this.accounts.aadharcard;
    console.log(this.userAccountNumber);
  }

}
