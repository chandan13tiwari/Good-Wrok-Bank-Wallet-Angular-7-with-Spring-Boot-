import { Component, OnInit } from '@angular/core';
import { AccountService } from '../account.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-new-account',
  templateUrl: './new-account.component.html',
  styleUrls: ['./new-account.component.css']
})
export class NewAccountComponent implements OnInit {

  constructor(private _accountService: AccountService, public router: Router) { }

  ngOnInit() {
  }

  onSubmit(username, password) {
    if(username === "" || password === ""){
      alert("Enter the Username & Password");
    }
    else{
    this._accountService.passUsernameAndPassword(username, password);
    this.router.navigate(['/createAccount']);
    }
  }

}
