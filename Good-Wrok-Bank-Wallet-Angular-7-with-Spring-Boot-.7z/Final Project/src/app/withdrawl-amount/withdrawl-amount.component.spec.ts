import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WithdrawlAmountComponent } from './withdrawl-amount.component';

describe('WithdrawlAmountComponent', () => {
  let component: WithdrawlAmountComponent;
  let fixture: ComponentFixture<WithdrawlAmountComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WithdrawlAmountComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WithdrawlAmountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
